class Product {
    constructor(name, quantity) {
        if (!name || quantity <= 0) {
            throw new Error("Nombre inválido o cantidad negativa.");
        }
        this.name = name;
        this.quantity = quantity;
    }
}

module.exports = Product;
