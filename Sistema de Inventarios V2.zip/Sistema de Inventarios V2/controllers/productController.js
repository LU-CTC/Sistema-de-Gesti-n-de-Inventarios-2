class ProductController {
    constructor() {
        this.products = [];
    }

    addProduct(product) {
        this.products.push(product);
    }

    deleteProduct(index) {
        if (index < 0 || index >= this.products.length) {
            throw new Error('Índice inválido.');
        }
        this.products.splice(index, 1);
    }

    getProducts() {
        return this.products;
    }

    updateProduct(index, updatedProduct) {
        if (index < 0 || index >= this.products.length) {
            throw new Error('Índice inválido.');
        }
        this.products[index] = updatedProduct;
    }
}

module.exports = ProductController;
