class ProductController {
    constructor() {
        this.products = [];
    }

    addProduct(product) {
        this.products.push(product);
    }

    deleteProduct(index) {
        if (index < 0 || index >= this.products.length) {
            throw new Error('Índice inválido.');
        }
        this.products.splice(index, 1);
    }

    getProducts() {
        return this.products;
    }
    
    updateProduct(index, updatedProduct) {
        if (index < 0 || index >= this.products.length) {
            throw new Error('Índice inválido.');
        }
        this.products[index] = updatedProduct;
    }
}

class Product {
    constructor(name, quantity) {
        if (!name || quantity <= 0) {
            throw new Error("Nombre inválido o cantidad negativa.");
        }
        this.name = name;
        this.quantity = quantity;
    }
}


class ProductView {
    constructor(controller) {
        this.controller = controller;
        this.tableBody = document.querySelector("#productTable tbody");
        this.addProductButton = document.querySelector("#addProductButton");
        this.productNameInput = document.querySelector("#productName");
        this.productQuantityInput = document.querySelector("#productQuantity");

        this.addProductButton.addEventListener("click", () => this.handleAddProduct());
    }

    handleAddProduct() {
        const name = this.productNameInput.value.trim();
        const quantity = parseInt(this.productQuantityInput.value);
    
        // Validaciones
        if (!name) {
            alert("El nombre del producto no puede estar vacío.");
            return;
        }
    
        if (isNaN(quantity) || quantity <= 0) {
            alert("La cantidad debe ser un número mayor a cero.");
            return;
        }
    
        try {
            const product = new Product(name, quantity);
            this.controller.addProduct(product);
            this.renderTable();
            this.clearInputs();
        } catch (error) {
            alert(error.message);
        }
    }

    renderTable() {
        this.tableBody.innerHTML = "";
        this.controller.getProducts().forEach((product, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${product.name}</td>
                <td>${product.quantity}</td>
                <td>
                    <button class="edit-button" data-index="${index}">Editar</button>
                    <button class="delete-button" data-index="${index}">Eliminar</button>
                </td>
            `;
            this.tableBody.appendChild(row);
        });
    
        // Vincula eventos a los botones
        const editButtons = this.tableBody.querySelectorAll('.edit-button');
        editButtons.forEach(button => {
            button.addEventListener('click', (event) => {
                const index = event.target.dataset.index;
                this.showEditForm(index);
            });
        });
    
        const deleteButtons = this.tableBody.querySelectorAll('.delete-button');
        deleteButtons.forEach(button => {
            button.addEventListener('click', (event) => {
                const index = event.target.dataset.index;
                this.controller.deleteProduct(index);
                this.renderTable();
            });
        });
    }
    
    showEditForm(index) {
    const product = this.controller.getProducts()[index];

    // Crea un formulario para editar el producto
    const editForm = document.createElement('div');
    editForm.innerHTML = `
        <input type="text" id="editName" value="${product.name}">
        <input type="number" id="editQuantity" value="${product.quantity}">
        <button id="saveEdit">Guardar</button>
        <button id="cancelEdit">Cancelar</button>
    `;
    this.tableBody.parentElement.appendChild(editForm);

    // Vincula eventos a los botones de guardar y cancelar
    document.getElementById('saveEdit').addEventListener('click', () => {
        const updatedName = document.getElementById('editName').value.trim();
        const updatedQuantity = parseInt(document.getElementById('editQuantity').value);

        if (!updatedName) {
            alert("El nombre del producto no puede estar vacío.");
            return;
        }
        if (isNaN(updatedQuantity) || updatedQuantity <= 0) {
            alert("La cantidad debe ser un número mayor a cero.");
            return;
        }

        try {
            const updatedProduct = new Product(updatedName, updatedQuantity);
            this.controller.updateProduct(index, updatedProduct);
            this.renderTable();
            editForm.remove(); // Elimina el formulario de edición
        } catch (error) {
            alert(error.message);
        }
    });

    document.getElementById('cancelEdit').addEventListener('click', () => {
        editForm.remove(); // Elimina el formulario de edición sin cambios
    });
}


    clearInputs() {
        this.productNameInput.value = "";
        this.productQuantityInput.value = "";
    }
}


document.addEventListener("DOMContentLoaded", () => {
    const controller = new ProductController();
    const view = new ProductView(controller);
});
