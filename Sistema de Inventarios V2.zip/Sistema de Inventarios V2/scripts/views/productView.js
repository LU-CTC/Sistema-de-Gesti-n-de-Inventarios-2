class ProductView {
    constructor(controller) {
        this.controller = controller;
        this.tableBody = document.querySelector("#productTable tbody");
        this.addProductButton = document.querySelector("#addProductButton");
        this.productNameInput = document.querySelector("#productName");
        this.productQuantityInput = document.querySelector("#productQuantity");

        this.addProductButton.addEventListener("click", () => this.handleAddProduct());
    }

    handleAddProduct() {
        const name = this.productNameInput.value.trim();
        const quantity = parseInt(this.productQuantityInput.value);
    
        // Validaciones
        if (!name) {
            alert("El nombre del producto no puede estar vacío.");
            return;
        }
    
        if (isNaN(quantity) || quantity <= 0) {
            alert("La cantidad debe ser un número mayor a cero.");
            return;
        }
    
        try {
            const product = new Product(name, quantity);
            this.controller.addProduct(product);
            this.renderTable();
            this.clearInputs();
        } catch (error) {
            alert(error.message);
        }
    }
    

    renderTable() {
        this.tableBody.innerHTML = "";
        this.controller.getProducts().forEach((product, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${product.name}</td>
                <td>${product.quantity}</td>
                <td>
                    <button class="delete-button" data-index="${index}">Eliminar</button>
                </td>
            `;
            this.tableBody.appendChild(row);
        });
    
        // Vincula el evento click a cada botón de eliminar
        const deleteButtons = this.tableBody.querySelectorAll('.delete-button');
        deleteButtons.forEach(button => {
            button.addEventListener('click', (event) => {
                const index = event.target.dataset.index;
                this.controller.deleteProduct(index);
                this.renderTable(); // Actualiza la tabla después de eliminar
            });
        });
    }
    

    clearInputs() {
        this.productNameInput.value = "";
        this.productQuantityInput.value = "";
    }
}

module.exports = ProductView;
