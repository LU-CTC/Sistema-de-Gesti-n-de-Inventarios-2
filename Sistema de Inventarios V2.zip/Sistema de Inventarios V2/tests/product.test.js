const Product = require('../models/productModel');
const ProductController = require('../controllers/productController');

test('Crear un producto con datos válidos', () => {
    const product = new Product('Producto X', 10);
    expect(product.name).toBe('Producto X');
    expect(product.quantity).toBe(10);
});

test('Rechazar producto con cantidad negativa', () => {
    expect(() => new Product('Producto Y', -5)).toThrow('Nombre inválido o cantidad negativa.');
});

test('Agregar y eliminar productos', () => {
    const controller = new ProductController();
    const product = new Product('Producto Z', 5);
    controller.addProduct(product);
    expect(controller.getProducts()).toContain(product);

    controller.deleteProduct(0);
    expect(controller.getProducts()).not.toContain(product);
});
